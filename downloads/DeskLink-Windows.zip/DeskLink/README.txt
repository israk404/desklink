DeskLink 1.0.0 for Windows
=================================

1. Keep this whole folder together (for example in Documents\DeskLink).
2. Double-click DeskLink.exe.
3. When Windows Firewall asks, tick "Private networks" and click Allow
   (it may show as "pythonw.exe" — that's DeskLink's built-in runtime).
4. Install DeskLink.apk on your phone, then click "Pair phone" here.

Tip: drag a photo onto DeskLink.exe to open it straight in Photo Fix.

If SmartScreen says "Windows protected your PC": More info -> Run anyway.

Guide: https://github.com/israk404/desklink#readme
